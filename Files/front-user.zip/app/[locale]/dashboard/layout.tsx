"use client"
export default function DashboardLayout({
    children,
  }: Readonly<{
    children: React.ReactNode;
  }>) {
    
  return (
      <section>
        {children}
      </section>
  );
}
  