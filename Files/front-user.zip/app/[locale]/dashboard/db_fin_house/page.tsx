'use client'
import React from 'react';
import BaseRenderer from '@/components/BaseRenderer';
import { useRouter, usePathname  } from 'next/navigation';

const DashboardFinWarehousePage = () => {
  const xrouter = useRouter();
  return (
    <div>
      <h1>Welcome to the DashboardFinWarehousePage</h1>
    </div>
  );
};

export default DashboardFinWarehousePage;