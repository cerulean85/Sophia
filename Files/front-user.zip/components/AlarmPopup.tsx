"use client";
import { setVisibleAlarmPopup } from '@/stores/appConfigSlice'
import { useSelector } from 'react-redux';
import { RootState } from '@/stores/store';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/stores/store';
import Image from "next/image";
import Bullet from '@/assets/icon/Bullet';
import { useEffect, useState } from "react";
import { Alarm } from '@/models/Alarm';
import {
  getAlarmList,
  getAlarmDetail
} from '@/controllers/AlarmController'

export default function AlarmPopup() {

  const dispatch: AppDispatch = useDispatch();
  const visibleAlarmPopup = useSelector((state: RootState) => state.appConfig.visibleAlarmPopup);
  const selectedAlarmId = useSelector((state: RootState) => state.appConfig.selectedAlarmId);

  const [alarmList, setAlarmList] = useState<Alarm[]>([]);
  const [alarmDetail, setAlarmDetail] = useState<Alarm>();

  useEffect(() => {
    
    (
      async function () {
        const alarmList: Alarm[] = await getAlarmList();
        setAlarmList(alarmList);

        const alarmDetail: Alarm = await getAlarmDetail(selectedAlarmId);
        setAlarmDetail(alarmDetail);
      }
    )();

  }, [selectedAlarmId]);

  const closeAlarmPopup = () => { dispatch(setVisibleAlarmPopup(false)); }

    return (
      <div className={`popup-overlay ${visibleAlarmPopup ? 'popup-visible':'popup-hidden'}`}>
        <div className='popup-contents'>
          <div className='popup-title d-flex align-items-center justify-content-between px-3'>
            <div>알람 발생</div>
            <a className='popup-close-btn d-flex align-items-center justify-content-center' onClick={closeAlarmPopup}>
              <Image src="/images/icon/ic_close.svg" width={18} height={18} alt='close'/>
            </a>
          </div>
          
          <div className="popup-message">
              <div className='d-flex align-items-center justify-content-center'>
                <Image src="/images/icon/ic_siren.gif" alt="GIF 예제" width={158} height={158} />
                <div className='message d-flex align-items-center text-start'>
                  <div>
                    <strong>Gantry #1</strong>에서 알람이 발생하였습니다.<br/>담당자는 알람을 처리하십시오. (발생: {alarmList.length}건)
                  </div>                
                </div>
              </div>
            </div>  

          <div className='popup-alarm-contents d-flex'>
            <div className={`when-${alarmList.length > 1 ? 'has' : 'none'}-alarm-list-detail overflow-auto p-3 m-2`}>
              
              <div className='d-flex'>
                <Bullet />
                <label className='me-2'><b>알람코드</b></label>
                <span>{alarmDetail?.code}</span>
              </div>
              
              <div className='d-flex mt-3'>
                <Bullet />
                <label className='me-2'><b>발생일시</b></label>
                <span>{alarmDetail?.date}</span>
              </div>

              <div className='d-flex mt-3'>
                <Bullet />
                <label className='me-2'><b>매뉴얼</b></label>                
              </div>
              <div>
                  {
                    alarmDetail?.manuals.map((d: any, i: any) => (
                      <div className='d-flex'>
                        <Image className="ms-2" src="/images/icon/ic_detail.svg" width={18} height={18} alt='View'/>
                        <a href={d.url} target="_blank">{d.name}</a>
                      </div>
                    ))
                  }
              </div>

              <div className='d-flex mt-3'>
                <Bullet />
                <label className='me-2'><b>조치방법</b></label>
              </div>
              <div>
                <pre>
                  <div>
                  1) 화면을 킨다. <br/>
                  2) 조치한다.
                  </div>
                </pre>
              </div>

              <div className='d-flex'>
                <Bullet />
                <label className='me-2'><b>담당자</b></label>
              </div>
              <div className='alarm-tb'>
                <div className="d-flex">
                  <div className='th-name d-flex align-items-center justify-content-center'>이름</div>
                  <div className='th-email d-flex align-items-center justify-content-center'>이메일</div>
                  <div className='th-phone d-flex align-items-center justify-content-center'>전화번호</div>            
                </div>

                {alarmDetail?.people.map((d: any, i: any) => (
                  <div className="d-flex">
                    <div className='td-name d-flex align-items-center justify-content-center'>{d.name}</div>
                    <div className='td-email d-flex align-items-center justify-content-center'>{d.email}</div>
                    <div className='td-phone d-flex align-items-center justify-content-center'>{d.phone}</div>            
                  </div>
                ))}

              </div>

            </div>            
            

            
            <div className={`when-${alarmList.length > 1 ? 'has' : 'none'}-alarm-list overflow-auto p-3`}>

            <div className='d-flex list'>
                <Bullet />
                <label className='me-2'><b>알람 목록&nbsp;({alarmList.length})</b></label>
              </div>
              <div className='alarm-tb'>
                <div className="d-flex">
                  <div className='th-code d-flex align-items-center justify-content-center'>알람코드</div>
                  <div className='th-point d-flex align-items-center justify-content-center'>발생일시</div>
                </div>

                {alarmList.map((d: any, i: any) => (
                  <div className="d-flex">
                      <div className='td-code d-flex align-items-center justify-content-center'>
                        <a onClick={() => alert("ㅋㅋㅋ")}>
                          {d.code}
                        </a>
                        <Image className='ms-1' src="/images/icon/ic_detail.svg" width={18} height={18} alt='View'/>
                      </div>
                      <div className='td-point d-flex align-items-center justify-content-center'>{d.date}</div>
                  </div>
                ))}  

              </div>
            </div>
          </div>
        </div>
      </div>
    );
}

