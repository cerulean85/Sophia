const CommonFooter = () => {
    return (
        <footer>
            <div className="footer-container">
                &copy; 2025. Hanwha Momentum. All Rights Reserved.
            </div>
        </footer>
    )
}

export default CommonFooter;