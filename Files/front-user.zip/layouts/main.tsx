'use client';  // 클라이언트 전용 컴포넌트임을 명시

import { ReactNode } from 'react';
import AlarmPopup from "@/components/AlarmPopup";
import { setVisibleAlarmPopup, setVisibleNotiDetailPopup } from '@/stores/appConfigSlice'
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '@/stores/store';

import { useState } from 'react';
import NotiSidePopup from '@/components/NotiSidePopup';
import NotiDetailPopup from '@/components/NotiDetailPopup';

export default function CommonMain({ children }: { children: ReactNode }) {

	const dispatch: AppDispatch = useDispatch();
	// const closeAlarmPopup = () => {dispatch(setVisibleAlarmPopup(false)); }
	// const openAlarmPopup = () => {dispatch(setVisibleAlarmPopup(true)); }

	// closeAlarmPopup();
	const openNotiPopup = () => {dispatch(setVisibleNotiDetailPopup(true)); }
	// openNotiPopup();

	const isSpreadMainMenu: boolean = useSelector((state: RootState) => state.appConfig.isSpreadMainMenu);

  return (
		<main className={`main-${isSpreadMainMenu ? 'spread':'fold'} `}>

			{/* <div>
				테스트 영역
				<button className="btn btn-primary" onClick={openAlarmPopup}>팝업열기</button>
			</div> */}
			{children}

      <AlarmPopup />
			<NotiSidePopup />
			<NotiDetailPopup />
		</main>
	)
}
