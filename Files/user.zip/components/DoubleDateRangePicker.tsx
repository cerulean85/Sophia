'use client'
import React, { useState } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Image from 'next/image'
import { getWeekNumber } from '@/lib/utils';

export default function DoubleDateRangePicker() {
	const [startDate, setStartDate] = useState<Date | null>(new Date());
	const [endDate, setEndDate] = useState<Date | null>(new Date());
	const update = () => {
		const _beforeWeek = getWeekNumber(String(startDate));
		// onSearch(_beforeWeek);
	}
	return (
		<div className='daterange-picker d-flex align-items-center border border-black'>
			<Image className='ms-2' src="/images/icon/ic_calendar.svg" width={24} height={24} alt='날짜선택'/>
			<DatePicker
				className="datepicker p-2"
				selected={startDate}
				onChange={(date) => setStartDate(date)}
				dateFormat="yyyy-MM-dd" />
			{/* {
			hideEndDate ? null :  */}
			-
			<DatePicker
				className="datepicker p-2"
				selected={endDate}
				onChange={(date) => setEndDate(date)}
				dateFormat="yyyy-MM-dd" />
			{/* } */}
			
			<div className='datepicker-btn d-flex justify-content-center align-items-center' onClick={update}>
				조회
			</div>
		</div>

	);
}