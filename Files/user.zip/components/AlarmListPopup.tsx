"use client";
import { setVisibleAlarmPopup } from '@/stores/appConfigSlice'
import { useSelector } from 'react-redux';
import { RootState } from '@/stores/store';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/stores/store';
import Image from "next/image";
import Bullet from '@/assets/icon/Bullet';
import { useEffect, useState } from "react";

interface AlarmPopupProps {
    params: any;
}

interface AlarmCodeProps {
  code: string;
  date: string;
}

interface AlarmPersonProps {
  name: string;
  email: string;
  phone: string;
}

interface AlarmManualProps {
  name: string;
  url: string;
}

interface AlarmDetailProps {
  code: string;
  date: string;
  manuals: AlarmManualProps[];
  action: string;
  people: AlarmPersonProps[];
}

export default function AlarmPopup({ params }: AlarmPopupProps) {

  const dispatch: AppDispatch = useDispatch();
  const visibleAlarmPopup = useSelector((state: RootState) => state.appConfig.visibleAlarmPopup);

  const [alarmList, setAlarmList] = useState<AlarmCodeProps[]>([]);
  const [alarmDetail, setAlarmDetail] = useState<AlarmDetailProps>();

  useEffect(() => {
    const alarmList: AlarmCodeProps[] = [
        { code: "CODE1", date: "2023-01-31 12:12:24" },
        { code: "CODE2", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },
        { code: "CODE3", date: "2023-01-31 12:12:24" },

      ];

      setAlarmList(alarmList);

      const alarmDetail: AlarmDetailProps = {
        code: "CODE1",
        date: "2023-01-01 12:12:24",
        manuals: [
          {
            name: "조치매뉴얼1.pdf",
            url: "http://localhost:3000/samples/sample.pdf"
          },
          {
            name: "조치방법.jpg",
            url: "http://localhost:3000/samples/sample.pdf"
          },
        ],
        action: "1) 화면을 킨다. <br/>2) 조치한다.",
        people: [
          {
            name: "아무개",
            email: "abc@test.com",
            phone: "010-1111-2222"
          },
          {
            name: "아무개",
            email: "abc@test.com",
            phone: "010-1111-2222"
          }
        ]
      };

      setAlarmDetail(alarmDetail);
  }, [])

    return (
      <div className={`popup-overlay ${visibleAlarmPopup ? 'popup-visible':'popup-hidden'}`}>
        <div className='popup-contents'>
          <div className='popup-title d-flex align-items-center justify-content-between px-3'>
            <div>알람 목록</div>
            <a className='popup-close-btn d-flex align-items-center justify-content-center'>
              <Image src="/images/icon/ic_close.svg" width={18} height={18} alt='close'/>
            </a>
          </div>

          <div className='popup-alarm-contents d-flex'>
                                     
            <div className={`when-${alarmList.length > 1 ? 'has' : 'none'}-alarm-list overflow-auto p-3`}>

            <div className='d-flex list'>
                <Bullet />
                <label className='me-2'><b>알람 목록&nbsp;({alarmList.length})</b></label>
              </div>
              <div className='alarm-tb'>
                <div className="d-flex">
                  <div className='th-code d-flex align-items-center justify-content-center'>알람코드</div>
                  <div className='th-point d-flex align-items-center justify-content-center'>발생일시</div>
                </div>

                {alarmList.map((d: any, i: any) => (
                  <div className="d-flex">
                      <div className='td-code d-flex align-items-center justify-content-center'>
                        <a onClick={() => alert("ㅋㅋㅋ")}>
                          {d.code}
                        </a>
                        <Image className='ms-1' src="/images/icon/ic_detail.svg" width={18} height={18} alt='View'/>
                      </div>
                      <div className='td-point d-flex align-items-center justify-content-center'>{d.date}</div>
                  </div>
                ))}  

              </div>
            </div>
          </div>
        </div>
      </div>
    );
}

