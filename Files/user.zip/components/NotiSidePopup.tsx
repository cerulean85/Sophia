"use client";

import { useRef, useEffect, useState } from "react";
import Image from "next/image";
import ToggleButton from "./ToogleButton";
import { 
  setVisibleAlarmPopup,
  setVisibleNotiSidePopup,
  setVisibleNotiDetailPopup,
  setSelectedAlarmId,
  setSelectedNotiId
} from '@/stores/appConfigSlice'
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '@/stores/store';

import { Noti } from "@/models/Noti";
import {
  getNotiList
} from '@/controllers/NotiController'

import { Alarm } from "@/models/Alarm";
import {
  getAlarmList
} from '@/controllers/AlarmController'

export default function NotiSidePopup() {
    const menuRef = useRef<HTMLDivElement>(null);

    const onClose = () => {
      dispatch(setVisibleNotiSidePopup(false));
    }
    
    const visibleNotiSidePopup: boolean = useSelector((state: RootState) => state.appConfig.visibleNotiSidePopup);

    useEffect(() => {

    }, [visibleNotiSidePopup])

    const [selectedNoti, setSelectedNoti] = useState(true);
    const [selectedAlarm, setSelectedAlarm] = useState(false);
    const [currentItems, setCurrentItems] = useState<any[]>([]);
    const [currentTab, setCurrentTab] = useState('noti');    

    useEffect(() => {
      (
        async function () {

          if (currentTab === "noti") {
            const notiList: Noti[] = await getNotiList();
            setCurrentItems(notiList);
          } else {
            const alarmList: Alarm[] = await getAlarmList();
            setCurrentItems(alarmList);
          }

        }
      )();
    }, [currentTab]);

    const releaseAll = () => {
      setSelectedNoti(false);
      setSelectedAlarm(false);
    }
    const selectNotiTab = () => {
      releaseAll();
      setSelectedNoti(true);
      setCurrentTab("noti");
    }

    const selectAlarmTab = () => {
      releaseAll();
      setSelectedAlarm(true);
      setCurrentTab("alarm");
    }

    const dispatch: AppDispatch = useDispatch();
    const openAlarmPopup = () => { dispatch(setVisibleAlarmPopup(true)); };
    const openNotiDetailPopup = () => { dispatch(setVisibleNotiDetailPopup(true)); };

    const showNoti = (id: number) => {
      dispatch(setSelectedNotiId(String(id)));
      openNotiDetailPopup(); 
    };
    const showAlarm = (id: number) => {
      dispatch(setSelectedAlarmId(String(id)));
      openAlarmPopup(); 
    };

    return (
        <div className="position-fixed z-999 vh-100 top-0 end-0" ref={menuRef}>
            {/* 드롭다운 메뉴 */}
            {visibleNotiSidePopup && (
              <div className="noti-board show position-absolute end-0">

                <div className="noti-title d-flex align-items-center justify-content-between px-3">
                  <div>알림</div>
                  <a className='popup-close-btn d-flex align-items-center justify-content-center' onClick={onClose}>
                    <Image src="/images/icon/ic_close.svg" width={18} height={18} alt='close'/>
                  </a>
                </div>
                <div className="noti-tab d-flex mt-3 px-2">
                  <ToggleButton
                    releasedImage="/images/icon/ic_megaphone_released.svg"
                    pressedImage="/images/icon/ic_megaphone_pressed.svg"
                    buttonSize={{width: "50%", height: "48px"}}
                    imageSize={{width: 22, height: 22}}
                    message="Notification"
                    releasedBgColor=""
                    pressedBgColor="#2C3E50"
                    onLoader={selectNotiTab}
                    selectedState={selectedNoti}
                    setSelectedState={setSelectedNoti}
                  ></ToggleButton>

                  <ToggleButton
                    releasedImage="/images/icon/ic_emergency_released.svg"
                    pressedImage="/images/icon/ic_emergency_pressed.svg"
                    buttonSize={{width: "50%", height: "48px"}}
                    imageSize={{width: 28, height: 32}}
                    message="Emergency"
                    releasedBgColor=""
                    pressedBgColor="#2C3E50"
                    onLoader={selectAlarmTab}
                    selectedState={selectedAlarm}
                    setSelectedState={setSelectedAlarm}
                  ></ToggleButton>
                </div>
                <div className="noti-list overflow-auto">
                  <div className="day ms-2 mt-2">최근 7일</div>
                  {currentItems.map((d: any, i: any) => (
                    <div 
                      className={`noti-item px-2 pb-2 ${i == 0 ? 'mt-2':''} d-flex`}
                      onClick={currentTab ==="alarm" ? () => {
                        showAlarm(d.id);
                      } : () => {
                        showNoti(d.id);
                      }}>
                      <div className="item p-2">
                        <div className="title">
                          <label className={`lb-${currentTab} `}>[{currentTab === "alarm" ? "알람" : "공지"}]</label> 
                          {currentTab === "alarm" ? " 알람이 발생하였습니다." : d.title }
                        </div>
                        <div className="date d-flex align-items-start">{d.date}</div>
                      </div>
                    </div>
                  ))}

                  <div className="day ms-2 mt-2">최근 30일</div>
                  {currentItems.map((d: any, i: any) => (
                    <div 
                      className={`noti-item px-2 pb-2 ${i == 0 ? 'mt-2':''}`}
                      onClick={currentTab ==="alarm" ? () => {
                        showAlarm(d.id);
                      } : () => {
                        showNoti(d.id);
                      }}>
                      <div className="item p-2">
                        <div className="title">
                          <label className={`lb-${currentTab} `}>[{currentTab === "alarm" ? "알람" : "공지"}]</label> 
                          {currentTab === "alarm" ? " 알람이 발생하였습니다." : d.title }
                        </div>
                        <div className="date d-flex align-items-start">{d.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
        </div>
    );
}
