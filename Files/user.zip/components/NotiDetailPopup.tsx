"use client";
import { setVisibleNotiDetailPopup } from '@/stores/appConfigSlice'
import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '@/stores/store';
import Image from "next/image";
import { useEffect, useState } from "react";
import { Noti } from '@/models/Noti';
import {
  getNotiDetail
} from '@/controllers/NotiController'

export default function AlarmPopup() {

  const dispatch: AppDispatch = useDispatch();
  const visible = useSelector((state: RootState) => state.appConfig.visibleNotiDetailPopup);
  const selectedId = useSelector((state: RootState) => state.appConfig.selectedNotiId);
  const [detail, setDetail] = useState<Noti>();

  useEffect(() => {  
    (
      async function () {      
        const detail: Noti = await getNotiDetail(selectedId);
        setDetail(detail);
      }
    )();

  }, [selectedId]);

  const close = () => { dispatch(setVisibleNotiDetailPopup(false)); }

    return (
      <div className={`popup-overlay ${visible ? 'popup-visible':'popup-hidden'}`}>
        <div className='popup-noti'>
          <div className='title d-flex align-items-center justify-content-between px-3'>
            <div>공지사항</div>
            <a className='close-btn d-flex align-items-center justify-content-center' onClick={close}>
              <Image src="/images/icon/ic_close.svg" width={18} height={18} alt='close'/>
            </a>
          </div>

          <div className='contents-ly'>
            <div className='title-ly d-flex align-items-center'>
              <Image src="/images/icon/ic_bullet_noti.svg" width={52} height={52} alt='Notification'/>          
              <div className='text-ly d-flex align-items-start ms-3'>
                <div className='parent-full'>
                  <div className='title-txt-ly'>
                    <div className='title-txt'>{detail?.title}</div>
                  </div>
                  <div className='date-txt d-flex justify-content-start'>{detail?.date}</div>
                </div>                
              </div>
            </div>
            <div className='desc-ly'>
              <div className='txt'>{detail?.description}</div>

            </div>
          </div>
          
        </div>
      </div>
    );
}

