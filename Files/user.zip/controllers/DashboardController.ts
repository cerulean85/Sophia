import { DashboardService } from "@/services/DashboardService";

const service = new DashboardService();

export async function getStorageStatics() {
	return await service.getStorageStatics();
}

export async function getAlarmStatics() {
	return await service.getAlarmStatics();
}

export async function getStorageTrend() {
	return await service.getStorageTrend();
}

export async function getShipTrend() {
	return await service.getShipTrend();
}

export async function getStackerCraneChart() {
	return await service.getStackerCraneChart();
}

export async function getGantryChart() {
	return await service.getGantryChart();
}