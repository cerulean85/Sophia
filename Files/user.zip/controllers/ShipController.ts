import { ShipService } from "@/services/ShipService";

const shipService = new ShipService();

export async function getCurrentShipList() {
	return await shipService.getCurrentShipList();
}

export async function getImportantItemList() {
	return await shipService.getImportantItemList();
}

export async function getSaveTrendList(beforeWeek: number) {

	return await shipService.getSaveTrendList(beforeWeek);
}

export async function getStackerCraneSaveList() {
	return await shipService.getStackerCraneSaveList();
}

export async function getGantrySaveList() {
	return await shipService.getGantrySaveList();
}

export async function getStackedCounts() {
	return await shipService.getStackedCounts();
}

export async function getPalletGroups() {
	return await shipService.getPalletGroups();
}

export async function getLongProductGroups() {
	return await shipService.getLongProductGroups();	
}