import { ShipService } from "@/services/ShipService";

const shipService = new ShipService();

export async function getCurrentShipList() {
	return await shipService.getCurrentShipList();
}
