export interface AlarmManual {
  name: string;
  url: string;
}
