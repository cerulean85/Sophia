export interface AlarmPerson {
  name: string;
  email: string;
  phone: string;
}