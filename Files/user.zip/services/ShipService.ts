import { GraphPoint } from "@/models/GraphPoint";
import { Noti } from "@/models/Noti";
import { ShipRepository } from "@/repositories/ShipRepository";

export class ShipService {
	private repo: ShipRepository;

	constructor() {
		this.repo = new ShipRepository();
	}

	async getSaveTrendList(beforeWeek: number): Promise<GraphPoint[]> {
		return await this.repo.getSaveTrendList(beforeWeek);
	}

	async getCurrentShipList(): Promise<any[]> {
		return await this.repo.getCurrentShipList();
	}

	async getImportantItemList(): Promise<GraphPoint[]> {
		return await this.repo.getImportantItemList();
	}

	async getStackerCraneSaveList(): Promise<any[]> {
		return await this.repo.getStackerCraneSaveList();
	}

	async getGantrySaveList(): Promise<any[]> {
		return await this.repo.getGantrySaveList();
	}

	async getStackedCounts(): Promise<any> {
		return await this.repo.getStackedCounts();
	}

	async getPalletGroups(): Promise<[]> {
		return await this.repo.getPalletGroups();
	}

	async getLongProductGroups(): Promise<{}> {
		return await this.repo.getLongProductGroups();
	}

	async getCraneStackedCounts(): Promise<{}> {
		return await this.repo.getCraneStackedCounts();
	}
}