import { GraphPoint } from "@/models/GraphPoint";
import { Noti } from "@/models/Noti";
import { ShipRepository } from "@/repositories/ShipRepository";

export class ShipService {
	private repo: ShipRepository;

	constructor() {
		this.repo = new ShipRepository();
	}

	async getCurrentShipList(): Promise<GraphPoint[]> {
		return await this.repo.getCurrentShipList();
	}
}