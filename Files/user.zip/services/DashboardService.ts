import { GraphPoint } from "@/models/GraphPoint";
import { Noti } from "@/models/Noti";
import { DashboardRepository } from "@/repositories/DashboardRepository";

export class DashboardService {
	private repo: DashboardRepository;

	constructor() {
		this.repo = new DashboardRepository();
	}

	async getStorageStatics(): Promise<any> {
		return await this.repo.getStorageStatics();
	}

	async getAlarmStatics(): Promise<any> {
		return await this.repo.getAlarmStatics();
	}

	async getStorageTrend(): Promise<any> {
		return await this.repo.getStorageTrend();
	}

	async getShipTrend(): Promise<any> {
		return await this.repo.getShipTrend();
	}

	async getStackerCraneChart(): Promise<any> {
		return await this.repo.getStackerCraneChart();
	}

	async getGantryChart(): Promise<any> {
		return await this.repo.getGantryChart();
	}
}