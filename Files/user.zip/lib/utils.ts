export function sumByKeyUpToIndex(arr: any[], key: string, index: number) {
	return arr.slice(0, index + 1).reduce((sum, obj) => sum + (obj[key] || 0), 0);
}