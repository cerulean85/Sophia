export function sumByKeyUpToIndex(arr: any[], key: string, index: number) {
	return arr.slice(0, index + 1).reduce((sum, obj) => sum + (obj[key] || 0), 0);
}

function sumUpToIndex(arr: any[], index: number) {
	return arr.slice(0, index + 1).reduce((sum, num) => sum + num, 0);
}

export function cumulativeSum(arr: any) {
	let sum = 0;
	return arr.map((num: number) => (sum += num));
}

export const getWeekNumber = (startDate: string): number => {
		const start = new Date(startDate); // 기준이 되는 시작 날짜
		const today = new Date(); // 현재 날짜
	
		// 시작 날짜의 시간을 00:00:00으로 설정
		start.setHours(0, 0, 0, 0);
		today.setHours(0, 0, 0, 0);
	
		// 경과한 일수 계산
		const diffTime = today.getTime() - start.getTime();
		const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
	
		// 주차 계산 (1주차부터 시작)
		return Math.floor(diffDays / 7) + 1;
	};

export const getTodayDate = () => {
	const today = new Date();
	const yyyy = today.getFullYear();
	const mm = String(today.getMonth() + 1).padStart(2, "0"); // 월 (0부터 시작하므로 +1 필요)
	const dd = String(today.getDate()).padStart(2, "0"); // 일
	const formattedDate = `${yyyy}-${mm}-${dd}`;
	return formattedDate
}