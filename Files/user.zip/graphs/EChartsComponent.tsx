'use client'
import React, { useEffect, useRef, useState } from 'react';
import * as echarts from 'echarts';

const EChartsComponent = ({ chartData } : { chartData: any }) => {

  const chartRef = useRef(null);

  // const [chartData, SetChartData] = useState<any>(null);
    
  // alert("123")
  // alert(_chartData)
  // useEffect(() => {
    // alert("!!!")
    // SetChartData(_chartData);
  // }, [_chartData]);

  useEffect(() => {
    const chartInstance = echarts.init(chartRef.current);
    chartInstance.showLoading({
      text: 'Loading...', effect: 'spin',
      textStyle: { fontSize: 20, fontWeight: 'bold', },
    });
  
    chartInstance.showLoading();

    setTimeout(() => {
      chartInstance.setOption(chartData);
      chartInstance.hideLoading();
    }, 1000);

    // 반응형 처리: 윈도우 크기가 변경되면 차트 리사이즈
    window.addEventListener('resize', () => {
      chartInstance.resize();
    });

    // 컴포넌트 언마운트 시 이벤트 리스너 제거
    return () => {
      window.removeEventListener('resize', () => {
        chartInstance.resize();
      });
      chartInstance.dispose();
    };
  }, [chartData])

  return <div ref={chartRef} style={{ width: '100%', height: '400px' }}></div>;
};

export default EChartsComponent;
