'use client'
import React, { useState, useEffect } from 'react';
import { RootState } from '@/stores/store';
import { useSelector } from 'react-redux';
import { 
  getStorageStatics,
  getAlarmStatics,
  getShipTrend,
  getStackerCraneChart,
  getGantryChart,
  getStorageTrend
} from '@/controllers/DashboardController';
import CurrentShipMixedChart2 from '@/graphs/CurrentShipMixedChart2';

const DashboardFinWarehousePage = () => {
  const lt: any = useSelector((state: RootState) => state.appConfig.localeText);
  
  const [storageStatics, setStorageStatics] = useState<any>(undefined);
  const [alarmStatics, setAlarmStatics] = useState<any>(undefined);
  const [storageTrend, setStorageTrend] = useState<any>(undefined);
  const [shipTrend, setShipTrend] = useState<any>(undefined);
  const [stackerCraneChart, setStackerCraneChart] = useState<any>(undefined);
  const [gantryChart, setGantryChart ] = useState<any>(undefined);
  useEffect(() => {
    (
      async function () {
        const data1 = await getStorageStatics();
        setStorageStatics(data1);

        const data2 = await getAlarmStatics();
        setAlarmStatics(data2);

        const data3 = await getStorageTrend();
        setStorageTrend(data3);

        const data4 = await getShipTrend();
        setShipTrend(data4);

        const data5 = await getStackerCraneChart();
        setStackerCraneChart(data5);

        const data6 = await getGantryChart();
        setGantryChart(data6);
      }
    )();    
  }, [])

  return (
    <div>
        <div style={{width: '35%', height: '100%', backgroundColor: 'blue'}}>
          <div className='series-chart-card' style={{width: '100%', height: '200px'}}>
            <div className='title d-flex justify-content-between'>
              <label>{lt.component.auto_storage_board}</label>
            </div>

            { storageStatics && 
            <div className='d-flex justify-content-between px-5 mt-4 text-center'>
              <div className='metric'>
                <div className='met-title'>적재최대치</div>
                <div className='met-value'>{String(storageStatics.maxCount).toLocaleString()}</div>
              </div>
              <div className='metric ms-3'>
                <div className='met-title'>실시간적재량</div>
                <div className='met-value'>{String(storageStatics.currentCount).toLocaleString()}</div>
              </div>
              <div className='metric ms-3'>
                <div className='met-title'>적재율</div>
                <div className='met-value'>{((storageStatics.currentCount / storageStatics.maxCount) * 100).toFixed(2)} %</div>
              </div>
            </div>
            }
          </div>

          { alarmStatics &&
          <div className='series-chart-card mt-3' style={{width: '100%', height: '260px'}}>
            <div className='title d-flex justify-content-between'>
              <label>알람 처리 현황</label>
            </div>
            
            <div className='d-flex justify-content-between mt-3 text-center px-3'>
              <div className='metric'>
                <div className='met-title'>총 발생</div>
                <div className='met-value' 
                    style={{
                      width: "120px",
                      height: "120px",
                      backgroundColor: "red",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "white",
                      marginTop: "10px"
                    }}>

                    {alarmStatics.total}
                </div>
              </div>

              { 
                alarmStatics.priority.map((d: any, i: any) => (
                  <div className='metric'>
                    <div className='met-title'>{d.name}</div>
                    <div className='met-value' 
                        style={{
                          width: "120px",
                          height: "120px",
                          backgroundColor: "green",
                          borderRadius: "50%",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: "white",
                          marginTop: "10px"
                        }}>
                          {d.count}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
          }

          {
            storageTrend &&
            <div className='series-chart-card mt-3' style={{width: '100%', height: '260px'}}>
              <div className='title d-flex justify-content-between'>
                <label>{lt.component.pallet_storage_board}</label>
              </div>

              <div className='chart'>
                <CurrentShipMixedChart2 currentShipList={storageTrend} />
              </div>          
            </div>    
          }

          {
            shipTrend &&
            <div className='series-chart-card mt-3' style={{width: '100%', height: '260px'}}>
              <div className='title d-flex justify-content-between'>
                <label>{lt.component.pallet_storage_board}</label>
              </div>

              <div className='chart'>
                <CurrentShipMixedChart2 currentShipList={shipTrend} />
              </div>          
            </div>    
          }
        </div>
    </div>
  );
};

export default DashboardFinWarehousePage;