'use client'
import React from 'react';
import BaseRenderer from '@/components/BaseRenderer';
import { useRouter, usePathname  } from 'next/navigation';

const RPReportPage = () => {
  const xrouter = useRouter();
  return (
    <div>
      <h1>Welcome to the RPReportPage</h1>
    </div>
  );
};

export default RPReportPage;