'use client'
import React, { useState } from 'react';
import { RootState } from '@/stores/store';
import { useSelector } from 'react-redux';
// import MixedLineBarChartComponent from '@/graphs/mixedLineBarChart';
import MixedLineBarChartComponent2 from '@/graphs/mixedLineBarChart2';
import DoughnutChart from '@/graphs/doughnutChart';
import EChartsComponent from '@/graphs/testChart'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Image from 'next/image'
import DoubleDateRangePicker from '@/components/DoubleDateRangePicker';
import StackedBarChart from '@/graphs/stackedBarChart'

const AlarmStatusPage = () => {
  const lt: any = useSelector((state: RootState) => state.appConfig.localeText);

  const alarmTotal = 1200;
  const alarmFin = 1080;
  const alarmRate = alarmTotal / alarmFin;

  let palletData: any = [
    { id: 1, type: "S/C #1", count: 100, stackCount: 453, average: 4.5 },
    { id: 2, type: "S/C #2", count: 200, stackCount: 1912, average: 9.5 },
    { id: 3, type: "S/C #3", count: 200, stackCount: 2800, average: 14.0 },
    { id: 4, type: "S/C #4", count: 250, stackCount: 4320, average: 17.2 },    
    { id: 4, type: "S/C #5", count: 250, stackCount: 4320, average: 17.2 },    
  ];

  const palletTotal = 750;
  const palletStackTotal = 750;
  const palletAver = 12.6;

  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  return (
    <div className='pb-3'>
      <div className='series-chart-card'>
        <div className='title d-flex justify-content-between'>
          <label>알람 발생 그래프</label>
          <DoubleDateRangePicker></DoubleDateRangePicker>
        </div>

        <div className='d-flex justify-content-between px-5 mt-4 '>
          <div className='metric'>
            <div className='met-title'>발생</div>
            <div className='met-value'>{alarmTotal.toLocaleString()}</div>
          </div>
          <div className='metric ms-3'>
            <div className='met-title'>처리</div>
            <div className='met-value'>{alarmFin.toLocaleString()}</div>
          </div>
          <div className='metric ms-3'>
            <div className='met-title'>처리율</div>
            <div className='met-value'>{alarmFin.toLocaleString()}</div>
          </div>
        </div>
        <div className='chart'>
          <MixedLineBarChartComponent2 />
        </div>               
      </div>

      <div className='al-cur-equip-series-card mt-3'>

        <div className='title d-flex justify-content-between'>
            <label>설비별 알람 발생 그래프</label>
            <DoubleDateRangePicker></DoubleDateRangePicker>
          </div>

        <div className='chart'>
          <StackedBarChart />

          <div className='d-flex'>
            <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>설비</th>
                  <th>수량</th>
                  <th>적재수량</th>
                  <th>평균</th>
                </tr>
              </thead>
              <tbody>
              {palletData.map((d: any, i: any) => (
                  <tr key={i}>
                    <td>{d.type}</td>
                    <td>{d.count}</td>
                    <td>{d.stackCount}</td>
                    <td>{d.average}</td>
                  </tr>
                ))}

                <tr>
                  <td>Total</td>
                  <td>{palletTotal}</td>
                  <td>{palletStackTotal}</td>
                  <td>{palletAver}</td>
                </tr>
              </tbody>
            </table>

            <table className="table table-bordered table-striped ms-3">
              <thead>
                <tr>
                  <th>설비</th>
                  <th>수량</th>
                  <th>적재수량</th>
                  <th>평균</th>
                </tr>
              </thead>
              <tbody>
              {palletData.map((d: any, i: any) => (
                  <tr key={i}>
                    <td>{d.type}</td>
                    <td>{d.count}</td>
                    <td>{d.stackCount}</td>
                    <td>{d.average}</td>
                  </tr>
                ))}

                <tr>
                  <td>Total</td>
                  <td>{palletTotal}</td>
                  <td>{palletStackTotal}</td>
                  <td>{palletAver}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>          
      </div>

    </div>
  );
};

export default AlarmStatusPage;