'use client'
import React, { useEffect, useState } from 'react';
import { RootState, AppDispatch } from '@/stores/store';
import { useSelector, useDispatch } from 'react-redux';
import DoughnutChartComponent from '@/graphs/doughnutChart';
import LogTrendChart from '@/graphs/LogTrendChart';
import DateRangePicker from '@/components/DateRangePicker';
import MixedLineBarChartComponent2 from '@/graphs/mixedLineBarChart2';
import MixedLineBarChartComponent3 from '@/graphs/mixedLineBarChart3';

import { GraphPoint } from '@/models/GraphPoint';
import {
  getCurrentShipList
} from '@/controllers/ShipController';

import { sumByKeyUpToIndex } from '@/lib/utils';

const LogisticsShipPage = () => {
  const lt: any = useSelector((state: RootState) => state.appConfig.localeText);

  const alarmTotal = 1200;
  const alarmFin = 1080;
  const alarmRate = alarmTotal / alarmFin;

  
  const [ currentShipList, setCurrentShipList ] = useState<GraphPoint[]>([]);

  useEffect(() => {
    setTimeout(() => {
      (
        async function () {
          const _curShipList: GraphPoint[] = await getCurrentShipList();
          setCurrentShipList(_curShipList);
        }
      )();

    }, 1000);
  }, [])

  const importantShipItems = [
    {
      "date": "12/31",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/30",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/29",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/28",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/27",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/26",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/25",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/24",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/23",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/22",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
    {
      "date": "12/21",
      "items": [
        { "item": "10001NX", "count": 94 },
        { "item": "10002NX", "count": 94 },
        { "item": "10003NX", "count": 94 },
        { "item": "10004NX", "count": 94 },
        { "item": "10005NX", "count": 94 },
      ]
    },
  ]

  return (
    <div className='pb-3'>
      <div className='series-chart-card'>
        <div className='title d-flex justify-content-between'>
          <label>출고량 현황</label>
          <DateRangePicker></DateRangePicker>
        </div>

        <div className='d-flex h-100'>
          <div className='w-50'>
            <div className='d-flex align-items-center justify-content-evenly px-5 mt-4 '>
              <div className='metric'>
                <div className='met-title'>출고량(최근)</div>
                <div className='met-value'>{alarmTotal.toLocaleString()}</div>
              </div>
              <div className='metric'>
                <div className='met-title'>누적 출고량</div>
                <div className='met-value'>{alarmFin.toLocaleString()}</div>
              </div>
            </div>
            <div className='d-flex justify-content-between'>
              <MixedLineBarChartComponent2 />
            </div>               
          </div>
          <div className='ship-trend-table'>
          <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>기간</th>
                  <th>출고량</th>
                  <th>누적출고량</th>
                </tr>
              </thead>
              <tbody>
              {currentShipList.map((d: any, i: any) => (
                  <tr key={i}>
                    <td>{d.x}</td>
                    <td>{d.y}</td>
                    <td>{sumByKeyUpToIndex(currentShipList, 'y', i)}</td>
                  </tr>
                ))}
              </tbody>
            </table>            
          </div>
        </div>
      </div>

      <div className='al-cur-equip-series-card mt-3'>

        <div className='title d-flex justify-content-between'>
            <label>중점 출고 규격</label>
            <DateRangePicker></DateRangePicker>
          </div>

        <div className='chart'>
          <MixedLineBarChartComponent3 />

          <div className='ship-imp-table'>
            {
              importantShipItems.map((d: any, i: any) => (
                <div className='ship-imp-table-column'>
                  <div className='ship-imp-table-row'>
                    <div className='ship-imp-table-date-cell'>{d.date}</div>
                  </div>
                  <div className='ship-imp-table-row'>
                    <div className='ship-imp-table-left-head'>품목</div>
                    <div className='ship-imp-table-right-head'>출고</div>
                  </div>

                  {d.items.map((sub: any, j: any) => (
                  <div className='ship-imp-table-row'>
                    <div className='ship-imp-table-left-cell'>{sub.item}</div>
                    <div className='ship-imp-table-right-cell'>{sub.count}</div>
                  </div>
                  ))}
                </div>    
              ))
            }

          </div>
        </div>          
      </div>

    </div>
  );
};
export default LogisticsShipPage;