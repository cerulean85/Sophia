'use client'
import React, { useState } from 'react';
import { RootState } from '@/stores/store';
import { useSelector } from 'react-redux';
import BaseRenderer from '@/components/BaseRenderer';
import { useRouter, usePathname  } from 'next/navigation';
import DateRangePicker from '@/components/DateRangePicker';
import StackedBarChart from '@/graphs/stackedBarChart'
import MixedLineBarChartComponent2 from '@/graphs/mixedLineBarChart2';

const LogisticsEquipStoragePage = () => {


  const lt: any = useSelector((state: RootState) => state.appConfig.localeText);

  const alarmTotal = 1200;
  const alarmFin = 1080;
  const alarmRate = alarmTotal / alarmFin;

  let palletData: any = [
    { 
      id: 1, 
      type: "S/C #1", 
      maxCount: 100, 
      currentCount: 453,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 2, 
      type: "S/C #2", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 3, 
      type: "S/C #3", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 4, 
      type: "S/C #4", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 5, 
      type: "S/C #5", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 6, 
      type: "S/C #6", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 7, 
      type: "S/C #7", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },
    { 
      id: 8, 
      type: "S/C #8", 
      maxCount: 453, 
      currentCount: 100,
      safetyCount: 100,
      items: ["A123", "A124", "A125"]
    },

  ];

  return (
    <div className='pb-3'>

      <div className='series-chart-card' style={{ height: '900px'}}>

        <div className='title d-flex justify-content-between'>
            <label>Stacker Crane별 적치 현황</label>
            <DateRangePicker></DateRangePicker>
          </div>

        <div className='chart'>
          <StackedBarChart />

          <div className='d-flex'>
            <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>설비</th>
                  <th>적치가능</th>
                  <th>적치</th>
                  <th>미적치</th>
                  <th>안전재고</th>
                  <th>적치율</th>
                  <th>품목수</th>
                </tr>
              </thead>
              <tbody>
              {palletData.map((d: any, i: any) => (
                  <tr key={i}>
                    <td>{d.type}</td>
                    <td>{d.maxCount}</td>
                    <td>{d.currentCount}</td>
                    <td>{d.maxCount - d.currentCount}</td>
                    <td>{d.safetyCount}</td>
                    <td>{(d.currentCount / d.maxCount ) * 100}%</td>
                    <td>{d.items.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>            
          </div>
        </div>          
      </div>

      <div className='series-chart-card mt-3' style={{ height: '900px'}}>

        <div className='title d-flex justify-content-between'>
            <label>Gantry별 적치 현황</label>
            <DateRangePicker></DateRangePicker>
          </div>

        <div className='chart'>
          <StackedBarChart />

          <div className='d-flex'>
            <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>설비</th>
                  <th>적치가능</th>
                  <th>적치</th>
                  <th>미적치</th>
                  <th>안전재고</th>
                  <th>적치율</th>
                  <th>품목수</th>
                </tr>
              </thead>
              <tbody>
              {palletData.map((d: any, i: any) => (
                  <tr key={i}>
                    <td>{d.type}</td>
                    <td>{d.maxCount}</td>
                    <td>{d.currentCount}</td>
                    <td>{d.maxCount - d.currentCount}</td>
                    <td>{d.safetyCount}</td>
                    <td>{((d.currentCount / d.maxCount ) * 100).toFixed(2)}%</td>
                    <td>{d.items.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>            
          </div>
        </div>          
      </div>


    </div>
  );
};

export default LogisticsEquipStoragePage;