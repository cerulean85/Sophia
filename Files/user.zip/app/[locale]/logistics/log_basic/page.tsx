'use client'
import React, { useEffect, useState } from 'react';
import { RootState } from '@/stores/store';
import { useSelector } from 'react-redux';
import SingleDateRangePicker from '@/components/SingleDateRangePicker';
import EChartsComponent from '@/graphs/EChartsComponent';
import { cumulativeSum } from '@/lib/utils';
import { GraphPoint } from '@/models/GraphPoint';
import {
  getPalletGroups,
  getSaveTrendList,
  getStackedCounts,
  getLongProductGroups
} from '@/controllers/ShipController';
import { useFormState } from 'react-dom';

interface LongProductProps {
  total_count: number,
  items: any[]
}

const LogisticsBasicStoragePage = () => {
  const lt: any = useSelector((state: RootState) => state.appConfig.localeText);

  const [maxSave, setMaxSave] = useState<number>(0);
  const [currentSave, setCurrentSave] = useState<number>(0);
  const [saveRate, setSaveRate] = useState<number>(0);
  const [palletData, setPalletData] = useState<[] | undefined>(undefined);
  const [longProductData, setLongProductData] = useState<LongProductProps | undefined>(undefined);

  const palletBaseName: any = {
    ">15": "5개 이하",
    "6AND10": "6개~10개",
    "11AND15": "11개~15개",
    "<=5": "16개 이상",
    "total": "합계"
  }

  const longProductBaseName: any = {
    "3MONTH_BELOW": "3개월 미만",
    "6MONTH_BELOW": "3개월 이상",
    "1YEAR_BELOW": "6개월 이상",
    "1YEAR_ABOVE": "1년 이상"
  }

  const [ trendChartData, setTrendChartData ] = useState<any>(null);
  useEffect(() => {
    updateStatics();
    updateChart(5); 
    updatePalletData();
    updateLongProductData();
  }, []);

  const updateStatics = async () => {
    const data: any = await getStackedCounts();
    setMaxSave(data.currentCount);
    setCurrentSave(data.totalCount);
    setSaveRate(data.rate);
  };

  const updateChart = async (beforeWeek: number) => {
    const data: GraphPoint[] = await getSaveTrendList(beforeWeek);
    const xValues = data.map(obj => obj.x);
    const yValues = data.map(obj => obj.y);
    const yCumValues = cumulativeSum(yValues);
    const chartData = {
      tooltip: { trigger: 'axis', },
      legend: {
        data: ['적치량', '누적적치량'],
        bottom: 0,
      },
      xAxis: { type: 'category', data: xValues },
      yAxis: [ 
        { 
          type: 'value',
          position: 'left',
          min: 0,
          max: Math.max(...yValues)
        },
        {
          type: 'value',
          position: 'right',
          min: 0,
          max: Math.max(...yCumValues)
        }
      ],
      series: [
        {
          name: '적치량', type: 'bar',
          data: yValues,
          emphasis: { focus: 'series' },
          yAxisIndex: 0
        },
        {
          name: '누적적치량', type: 'line',
          data: yCumValues,
          emphasis: { focus: 'series' },
          yAxisIndex: 1
        }
      ]
    };
    setTrendChartData(chartData);
  };

  const updatePalletData = async () => {
    const data: any = await getPalletGroups();
    setPalletData(data);
  }

  const updateLongProductData = async () => {
    const data: any = await getLongProductGroups();
    setLongProductData(data);
  }

  return (
    <div>
      <div className='series-chart-card' style={{height: '200px'}}>
        <div className='title d-flex justify-content-between'>
          <label>{lt.component.auto_storage_board}</label>
        </div>

        <div className='d-flex justify-content-between px-5 mt-4'>
          <div className='metric'>
            <div className='met-title'>적재최대치</div>
            <div className='met-value'>{maxSave.toLocaleString()}</div>
          </div>
          <div className='metric ms-3'>
            <div className='met-title'>실시간적재량</div>
            <div className='met-value'>{currentSave.toLocaleString()}</div>
          </div>
          <div className='metric ms-3'>
            <div className='met-title'>적재율</div>
            <div className='met-value'>{saveRate}%</div>
          </div>
        </div>
      </div>

      <div className='series-chart-card mt-3' style={{ height: '500px' }}>
      <div className='title d-flex justify-content-between'>
        <label>{lt.component.storage_graph}</label>
        <div className='d-flex align-items-center' style={{fontSize: "0.9rem" }}>
          <div className='me-2'>기준일 선택</div>
          <SingleDateRangePicker hideEndDate={true} onSearch={updateChart}></SingleDateRangePicker>
        </div>
      </div>

        <div className='chart'>
          {trendChartData && <EChartsComponent chartData={trendChartData} /> }
        </div>               
      </div>  


      <div className='series-chart-card mt-3' style={{height: '355px'}}>
        <div className='title d-flex justify-content-between'>
          <label>{lt.component.pallet_storage_board}</label>
        </div>

        <div className='chart'>
          <table className="table table-bordered table-striped text-center">
            <thead>
              <tr>
                <th>구분</th>
                <th>수량</th>
                <th>적재수량</th>
                <th>평균</th>
              </tr>
            </thead>
            <tbody>
            {palletData && palletData.map((d: any, i: any) => (
                <tr key={i}>
                  <td>{palletBaseName[d.name]}</td>
                  <td>{d.record_count}</td>
                  <td>{d.product_count}</td>
                  <td>{d.average}</td>
                </tr>
              ))}

            </tbody>
          </table>            
        </div>          
      </div>

      <div className='series-chart-card mt-3' style={{height: '310px'}}>
        <div className='title d-flex justify-content-between'>
          <label>{lt.component.long_product_storage_board}</label>
        </div>

        <div className='chart'>
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                <th>구분</th>
                <th>품목</th>
                <th>적재수량</th>
                <th>평균</th>
              </tr>
            </thead>
            <tbody>
            {longProductData && longProductData.items.map((d: any, i: any) => (
                <tr key={i}>
                  <td>{longProductBaseName[d.name]}</td>
                  <td>{d.types[0]}{d.types.length === 1 ? '' : ` 외 ${d.types.length - 1}건`}</td>
                  <td>{String(d.total_count).toLocaleString()}</td>
                  <td>{((d.total_count / longProductData.total_count) * 100).toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>            
        </div>          
      </div>
    </div> 
  );
};

export default LogisticsBasicStoragePage;