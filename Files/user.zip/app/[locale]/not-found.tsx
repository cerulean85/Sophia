import React from "react";

const NotFound = () => {
  return <div>요청하신 페이지는 존재하지 않습니다.222</div>;
};

export default NotFound;