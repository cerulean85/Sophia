import repoData from "./repo.json";

interface Repo {
  apiUrl?: string;
  deployment?: boolean;
  dummy?: Record<string, any>;
}

const repo: Repo = repoData; // JSON 데이터를 Repo 타입으로 변환

export async function reqGet(domain: string, dummyName: string = "") {
  try {
    if (repo.deployment && repo.apiUrl) {
      const response = await fetch(`${repo.apiUrl}/${domain}`);
      if (!response.ok) throw new Error("데이터를 불러오지 못했습니다.");
      const result = await response.json();
      return result;
    } else if (repo.dummy && repo.dummy[dummyName]) {
      return repo.dummy[dummyName];
    } else {
      throw new Error(`dummy 데이터에서 '${dummyName}'을 찾을 수 없습니다.`);
    }
  } catch (e) {
    console.error(e);
    return null; // 오류 발생 시 `null` 반환
  }
}
