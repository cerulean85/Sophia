import repo from './repo.json'
import {
	reqGet
} from "./req"

export class DashboardRepository {
	async getStorageStatics(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}

		return repo.dummy.dashboard.storageStatics;
	}

	async getAlarmStatics(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}
		return repo.dummy.dashboard.alarmStatics;
	}

	async getStorageTrend(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}
		return repo.dummy.dashboard.storageTrend;
	}

	async getShipTrend(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}
		return repo.dummy.dashboard.shipTrend;
	}

	async getStackerCraneChart(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}
		return repo.dummy.dashboard.stackerCraneChart;
	}

	async getGantryChart(): Promise<any> {
		if (repo.deployment) {
			// const res = await reqGet(`operation/users/${userSeqId}`);
			// const data: any = res.json();
			const rst: any = {};
			return rst;
		}
		return repo.dummy.dashboard.gantryChart;
	}
}