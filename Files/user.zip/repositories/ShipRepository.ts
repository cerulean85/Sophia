import { GraphPoint, getEmpty } from '@/models/GraphPoint';
import repo from './repo.json'
import {
	reqGet
} from "./req"

export class ShipRepository {
	async getCurrentShipList(): Promise<GraphPoint[]> {
		if (repo.deployment) {
			const res = await reqGet("something");
			const rst: any = res.json();
			const list: GraphPoint[] = rst.notiList;
			return list;
		}

		return repo.dummy.currentShipList;
	}
}