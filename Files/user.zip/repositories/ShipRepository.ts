import { GraphPoint, getEmpty } from '@/models/GraphPoint';
import repo from './repo.json'
import {
	reqGet
} from "./req"

export class ShipRepository {
	async getCurrentShipList(): Promise<GraphPoint[]> {
		if (repo.deployment) {
			const res = await reqGet("something");
			const rst: any = res.json();
			const list: GraphPoint[] = rst.notiList;
			return list;
		}

		return repo.dummy.currentShipList;
	}

	async getImportantItemList(): Promise<any[]> {
		if (repo.deployment) {
			const res = await reqGet("something");
			const rst: any = res.json();
			const list: GraphPoint[] = rst.notiList;
			return list;
		}

		return repo.dummy.importantItemList;
	}

	async getStackedCounts(): Promise<any> {
		const res = await reqGet(`pallet/getStackedCounts`, "stackedCounts");
		return res;
	}

	async getSaveTrendList(beforeWeek: number): Promise<GraphPoint[]> {
		const keyname = "saveTrendList";
		const res = await reqGet(`pallet/getWeekStackedCounts/${beforeWeek}`, "saveTrendList");
		if (keyname in res){
			return res[keyname];
		} else {
			const convertedData = Object.fromEntries(
				Object.entries(res).map(([key, value]) => [key, Number(value)])
			);

			const list: GraphPoint[] = Object.entries(convertedData).map(([x, y]) => ({ x, y }));
			return list;
		}
	}

	async getPalletGroups(): Promise<[]> {
		const keyname = "stackedCounts";
		const res = await reqGet(`pallet/getPalletGroups`, "stackedCounts");
		if (keyname in res){
			return res[keyname];
		} else {
			return res;
		}
	}

	async getLongProductGroups(): Promise<{}> {
		const keyname = "getLongProductGroups";
		const res = await reqGet(`pallet/getLongProductGroups`, "getLongProductGroups");
		if (keyname in res){
			return res[keyname];
		} else {
			return res;
		}		
	}

	async getCraneStackedCounts(): Promise<{}> {
		const keyname = "getCraneStackedCounts";
		const res = await reqGet(`pallet/getCraneStackedCounts`, "getCraneStackedCounts");
		if (keyname in res){
			return res[keyname];
		} else {
			return res;
		}		
	}

	async getStackerCraneSaveList(): Promise<any[]> {
		if (repo.deployment) {
			const res = await reqGet("something");
			const rst: any = res.json();
			const list: any[] = rst.notiList;
			return list;
		}

		return repo.dummy.equipmentSaveList.StackerCrane;
	}		

	async getGantrySaveList(): Promise<any[]> {
		if (repo.deployment) {
			const res = await reqGet("something");
			const rst: any = res.json();
			const list: any[] = rst.notiList;
			return list;
		}

		return repo.dummy.equipmentSaveList.Gantry;
	}		

}